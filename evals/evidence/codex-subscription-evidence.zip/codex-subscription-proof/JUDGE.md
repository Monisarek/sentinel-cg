# Recorded Codex subscription experiment

This collection retains all three attempts. The first reached discovery, synthesis,
promotion and replay, then stopped on an invalid zero value during fresh evaluation.
The second stopped when the local CLI produced no structured output. The third
completed using gpt-6.1-sol at medium reasoning through ChatGPT subscription login.

The completed run is codex-cycle-59163c43b68a4304b261f000b2406c96.
Red proposed staging connection_limit=5 and restart. Production fell from 8 to 7.
Blue proposed the included patch. Independent verification promoted it. Fixed-trace
replay kept production at 8 under v1. A fresh evaluation found no verified
counterexample within the recorded budget. All recorded model responses, prompt
hashes, session identifiers, decisions, reports and SQLite snapshots are retained.

Verify the archive SHA-256 through a trusted channel before extraction.
Hashes establish integrity. Recorded consistency does not authenticate inference
independently or prove universal safety. The machine export grade 'competition'
only records clean source provenance. Historical competition gates remain pending.

## Independent offline verification

From the directory containing the extracted codex-subscription-proof folder:

```text
git clone codex-subscription-proof/verified-cycle/source.bundle codex-verifier
cd codex-verifier
git checkout 901ce3bb0957769270ab530993436454cf616398
python -S -B -m scripts.verify_evidence ../codex-subscription-proof/first-schema-failure
python -S -B -m scripts.verify_evidence ../codex-subscription-proof/cli-startup-failure
python -S -B -m scripts.verify_evidence ../codex-subscription-proof/verified-cycle
```

Python 3.10+ and Git suffice. Verification reads recorded artifacts and makes no
model requests. The two unsuccessful attempts retain FAIL and their reasons.
verification-report.json records the separate cache-free verification, with
network/file writes/original-cache reads forbidden and unchanged file hashes.

## Open the recorded result in the workspace

From the current project checkout, after extracting this archive under
.cache/codex-recorded and building apps/web:

```text
python -m scripts.serve_evidence --output-dir .cache/codex-recorded/codex-subscription-proof/recorded-runs
```

Open http://127.0.0.1:8000/?run_id=codex-cycle-59163c43b68a4304b261f000b2406c96.
Opening the saved result uses no subscription. Run Codex experiment starts a new
model experiment and consumes the signed-in subscription's usage limits.
