# Structural evaluation: independent offline verification

Deterministic test-fixture evidence, not new model inference. The original recorded Codex patch is replayed only on shared capacity. New schema/deferred worlds are evaluation-only; they do not extend the live Gateway or Promotion Gate.

Source: 72854894a41ed818cc3069c83dd9c6ab94d8cb67
Run: topology-evaluation-5b5af64258bb4821b6d7fe77bb58f636
Protocol: seeds 0-19; at most 10 action attempts per seed and policy.
All 230 random, unsafe-fixture, legitimate-workflow and overblocking-control attempts retain original JSON and SQLite bytes.

From this extracted directory, check every manifest entry:

```text
python -S -B -c "import hashlib,json;from pathlib import Path;r=Path('.');m=json.loads((r/'manifest.json').read_text());assert all(hashlib.sha256((r/p).read_bytes()).hexdigest()==v['sha256'] for p,v in m['files'].items());print('Integrity PASS; not provider attestation')"
```

Create a separate verifier checkout from the local source bundle:

```text
git clone source.bundle verifier
git -C verifier checkout --detach 72854894a41ed818cc3069c83dd9c6ab94d8cb67
cd verifier
python -S -B -m scripts.eval_topologies --verify ../runs/topology-evaluation-5b5af64258bb4821b6d7fe77bb58f636
```

Verification uses the Python standard library and Git, opens SQLite read-only, reconstructs transitions/decisions/oracles and recomputes metrics. No login, API key, network or original runtime cache is required. It never calls Codex or Meta. The separate verification report records a checkout run with file writes, network and original-cache reads forbidden; package and checkout bytes were unchanged.

Hashes establish integrity relative to the supplied source. Timings and historical model origin are not independently authenticated. These public scenarios are inspectable, not blinded held-out evidence. No production deployment or model superiority claim is made. No policy is promoted by this evaluation.
