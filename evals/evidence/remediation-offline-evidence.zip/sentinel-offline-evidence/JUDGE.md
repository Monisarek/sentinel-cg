# Recorded offline evidence collection

All inference-shaped responses and candidate patches here are deterministic test
fixtures. No genuine Meta model call occurred. G3, AI-dependent G4/G7, and G8
remain PENDING. The blocked runtime is a genuine local refusal with zero calls.
The `competition` export grade means clean source provenance only.

Verify the downloaded ZIP SHA-256 against the publisher's `.sha256` file through a
trusted channel before extraction. Hashes establish integrity, not authenticity.
The collection manifest inventories all files, including every baseline attempt.

After extraction, use the self-contained source; Git and Python 3.10+ suffice:

```text
git clone sentinel-offline-evidence/core/source.bundle sentinel-verifier
cd sentinel-verifier
git checkout 4446dd3d4e84f2cc0de865421a34bdcb76527f7b
python -S -B -m scripts.verify_evidence ../sentinel-offline-evidence/core
python -S -B -m scripts.verify_evidence ../sentinel-offline-evidence/meta-full-fixture
python -S -B -m scripts.verify_evidence ../sentinel-offline-evidence/meta-blocked
python -S -B -m scripts.verify_evidence ../sentinel-offline-evidence/meta-bypass-fixture
```

Run these commands from the cloned source, not a newer working tree. Each package
preserves its raw JSON bytes, reports, traces, immutable policy records, and SQLite
snapshots. Verification is read-only and needs no key, original cache, installed
dependencies, paid inference, or network. `VERIFIED` preserves the original status:
the bypass remains FAIL/BYPASSED, the blocked run remains BLOCKED, and AI gates
remain PENDING. See each package's JUDGE.md for verification boundaries.

`clean-checkout-verification.json` records the separate clean-checkout experiment,
with original cache reads, file writes, and network calls forbidden. It is a test
receipt, not independent authentication of model provenance.

`baselines/` retains the first recorded random, direct-shield, and parameter-sweep
runs, including all unsuccessful random attempts. Their disclosed dirty source
flags are unchanged. The source commits are included as ancestors in source.bundle.
The per-package verifier accepts the four runtime proof formats, not baseline
report formats; baseline files are covered by the collection's SHA-256 inventory
and original record hashes. To reproduce measurements independently, the bundled
source provides `python -m scripts.eval_random`, `python -m scripts.eval_shield`,
and `python -m scripts.eval_parametric`. These reproduction commands write fresh
local output, unlike the read-only verification commands above. They use no models.
No claim of Meta superiority or LLM necessity is supported by these baselines.
